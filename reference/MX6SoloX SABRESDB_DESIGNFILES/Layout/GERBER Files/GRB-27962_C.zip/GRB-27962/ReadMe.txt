README for GRB-27962_C.zip

Company Part Number: 170-27962 REV C

Date: Mon, 22 Dec 2014 04:25:56 GMT

Freescale Semiconductor
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@freescale.com

CAD Manager
===========
Company Contact     : Raymond Villalobos
Work Phone          : 512-895-6081
Email               : Raymond.Villalobos@freescale.com

Manufacturing Program Manager
=============================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@freescale.com

Product Engineer
================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@freescale.com
